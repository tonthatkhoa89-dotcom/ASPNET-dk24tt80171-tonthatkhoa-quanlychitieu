USE PersonalFinanceDb;
GO

/*
    Dữ liệu mẫu từ 01/2025 đến 06/2026.
    File này chỉ tạo dữ liệu mẫu, không chứa câu init database/schema
*/

DECLARE @AdminId INT, @User01Id INT;
DECLARE @IncomeTypeId INT, @ExpenseTypeId INT, @SavingTypeId INT;
DECLARE @CatLuong INT, @CatThuong INT, @CatAnUong INT, @CatDiLai INT, @CatMuaSam INT, @CatTienMat INT;

SELECT @IncomeTypeId = TypeId FROM TransactionTypes WHERE TypeCode = 'Income';
SELECT @ExpenseTypeId = TypeId FROM TransactionTypes WHERE TypeCode = 'Expense';
SELECT @SavingTypeId = TypeId FROM TransactionTypes WHERE TypeCode = 'Saving';

SELECT @CatLuong = CategoryId FROM Categories WHERE TypeId=@IncomeTypeId AND CategoryName=N'Lương';
SELECT @CatThuong = CategoryId FROM Categories WHERE TypeId=@IncomeTypeId AND CategoryName=N'Thưởng';
SELECT @CatAnUong = CategoryId FROM Categories WHERE TypeId=@ExpenseTypeId AND CategoryName=N'Ăn uống';
SELECT @CatDiLai = CategoryId FROM Categories WHERE TypeId=@ExpenseTypeId AND CategoryName=N'Đi lại';
SELECT @CatMuaSam = CategoryId FROM Categories WHERE TypeId=@ExpenseTypeId AND CategoryName=N'Mua sắm';
SELECT @CatTienMat = CategoryId FROM Categories WHERE TypeId=@SavingTypeId AND CategoryName=N'Tiền mặt';

IF @IncomeTypeId IS NULL OR @ExpenseTypeId IS NULL OR @SavingTypeId IS NULL
   OR @CatLuong IS NULL OR @CatThuong IS NULL OR @CatAnUong IS NULL
   OR @CatDiLai IS NULL OR @CatMuaSam IS NULL OR @CatTienMat IS NULL
BEGIN
    RAISERROR(N'Thiếu dữ liệu khởi tạo. Hãy chạy file 01_create_database.sql trước.', 16, 1);
    RETURN;
END;

IF NOT EXISTS (SELECT 1 FROM Users WHERE Username=N'admin')
BEGIN
    INSERT INTO Users(Username, PasswordHash, FullName, IsActive, IsAdmin)
    VALUES (N'admin', '240BE518FABD2724DDB6F04EEB1DA5967448D7E831C08C8FA822809F74C720A9', N'Administrator', 1, 1);
END
ELSE
BEGIN
    UPDATE Users
    SET PasswordHash='240BE518FABD2724DDB6F04EEB1DA5967448D7E831C08C8FA822809F74C720A9',
        FullName=N'Administrator',
        IsActive=1,
        IsAdmin=1
    WHERE Username=N'admin';
END;

IF NOT EXISTS (SELECT 1 FROM Users WHERE Username=N'user01')
BEGIN
    INSERT INTO Users(Username, PasswordHash, FullName, IsActive, IsAdmin)
    VALUES (N'user01', '349604023FF22A6AF290A9CB6C72C69EF31AFEEFCE0E40A02C8179111BFD676A', N'Người dùng thường 01', 1, 0);
END
ELSE
BEGIN
    UPDATE Users
    SET PasswordHash='349604023FF22A6AF290A9CB6C72C69EF31AFEEFCE0E40A02C8179111BFD676A',
        FullName=N'Người dùng thường 01',
        IsActive=1,
        IsAdmin=0
    WHERE Username=N'user01';
END;

SELECT @AdminId = UserId FROM Users WHERE Username=N'admin';
SELECT @User01Id = UserId FROM Users WHERE Username=N'user01';

DECLARE @CurrentMonth DATE = '2025-01-01';
DECLARE @EndMonth DATE = '2026-06-01';
DECLARE @MonthText NVARCHAR(7);
DECLARE @MonthNo INT;
DECLARE @YearNo INT;

WHILE @CurrentMonth <= @EndMonth
BEGIN
    SET @MonthNo = MONTH(@CurrentMonth);
    SET @YearNo = YEAR(@CurrentMonth);
    SET @MonthText = RIGHT('0' + CAST(@MonthNo AS VARCHAR(2)), 2) + N'/' + CAST(@YearNo AS VARCHAR(4));

    -- user01: thu nhập, tiết kiệm, chi tiêu hằng tháng
    INSERT INTO Transactions(UserId, TypeId, CategoryId, TransactionDate, Amount, Note)
    SELECT @User01Id, @IncomeTypeId, @CatLuong, DATEFROMPARTS(@YearNo, @MonthNo, 5), 15000000 + ((@MonthNo % 3) * 250000), N'Lương tháng ' + @MonthText
    WHERE NOT EXISTS (
        SELECT 1 FROM Transactions
        WHERE UserId=@User01Id AND TransactionDate=DATEFROMPARTS(@YearNo, @MonthNo, 5)
          AND TypeId=@IncomeTypeId AND CategoryId=@CatLuong AND Note=N'Lương tháng ' + @MonthText
    );

    INSERT INTO Transactions(UserId, TypeId, CategoryId, TransactionDate, Amount, Note)
    SELECT @User01Id, @IncomeTypeId, @CatThuong, DATEFROMPARTS(@YearNo, @MonthNo, 20), 1000000 + ((@MonthNo % 4) * 500000), N'Thưởng tháng ' + @MonthText
    WHERE NOT EXISTS (
        SELECT 1 FROM Transactions
        WHERE UserId=@User01Id AND TransactionDate=DATEFROMPARTS(@YearNo, @MonthNo, 20)
          AND TypeId=@IncomeTypeId AND CategoryId=@CatThuong AND Note=N'Thưởng tháng ' + @MonthText
    );

    INSERT INTO Transactions(UserId, TypeId, CategoryId, TransactionDate, Amount, Note)
    SELECT @User01Id, @SavingTypeId, @CatTienMat, DATEFROMPARTS(@YearNo, @MonthNo, 10), 1200000 + ((@MonthNo % 5) * 200000), N'Tiết kiệm tiền mặt tháng ' + @MonthText
    WHERE NOT EXISTS (
        SELECT 1 FROM Transactions
        WHERE UserId=@User01Id AND TransactionDate=DATEFROMPARTS(@YearNo, @MonthNo, 10)
          AND TypeId=@SavingTypeId AND CategoryId=@CatTienMat AND Note=N'Tiết kiệm tiền mặt tháng ' + @MonthText
    );

    INSERT INTO Transactions(UserId, TypeId, CategoryId, TransactionDate, Amount, Note)
    SELECT @User01Id, @ExpenseTypeId, @CatAnUong, DATEFROMPARTS(@YearNo, @MonthNo, 2), 220000 + (@MonthNo * 9000), N'Ăn uống ngày 02/' + @MonthText
    WHERE NOT EXISTS (
        SELECT 1 FROM Transactions WHERE UserId=@User01Id AND TransactionDate=DATEFROMPARTS(@YearNo, @MonthNo, 2) AND Note=N'Ăn uống ngày 02/' + @MonthText
    );

    INSERT INTO Transactions(UserId, TypeId, CategoryId, TransactionDate, Amount, Note)
    SELECT @User01Id, @ExpenseTypeId, @CatDiLai, DATEFROMPARTS(@YearNo, @MonthNo, 12), 120000 + (@MonthNo * 7000), N'Đi lại ngày 12/' + @MonthText
    WHERE NOT EXISTS (
        SELECT 1 FROM Transactions WHERE UserId=@User01Id AND TransactionDate=DATEFROMPARTS(@YearNo, @MonthNo, 12) AND Note=N'Đi lại ngày 12/' + @MonthText
    );

    INSERT INTO Transactions(UserId, TypeId, CategoryId, TransactionDate, Amount, Note)
    SELECT @User01Id, @ExpenseTypeId, @CatMuaSam, DATEFROMPARTS(@YearNo, @MonthNo, 24), 300000 + (@MonthNo * 15000), N'Mua sắm ngày 24/' + @MonthText
    WHERE NOT EXISTS (
        SELECT 1 FROM Transactions WHERE UserId=@User01Id AND TransactionDate=DATEFROMPARTS(@YearNo, @MonthNo, 24) AND Note=N'Mua sắm ngày 24/' + @MonthText
    );

    -- admin: thu nhập, tiết kiệm, chi tiêu hằng tháng
    INSERT INTO Transactions(UserId, TypeId, CategoryId, TransactionDate, Amount, Note)
    SELECT @AdminId, @IncomeTypeId, @CatLuong, DATEFROMPARTS(@YearNo, @MonthNo, 5), 23000000 + ((@MonthNo % 3) * 250000), N'Lương tháng ' + @MonthText
    WHERE NOT EXISTS (
        SELECT 1 FROM Transactions
        WHERE UserId=@AdminId AND TransactionDate=DATEFROMPARTS(@YearNo, @MonthNo, 5)
          AND TypeId=@IncomeTypeId AND CategoryId=@CatLuong AND Note=N'Lương tháng ' + @MonthText
    );

    INSERT INTO Transactions(UserId, TypeId, CategoryId, TransactionDate, Amount, Note)
    SELECT @AdminId, @IncomeTypeId, @CatThuong, DATEFROMPARTS(@YearNo, @MonthNo, 20), 1500000 + ((@MonthNo % 4) * 500000), N'Thưởng tháng ' + @MonthText
    WHERE NOT EXISTS (
        SELECT 1 FROM Transactions
        WHERE UserId=@AdminId AND TransactionDate=DATEFROMPARTS(@YearNo, @MonthNo, 20)
          AND TypeId=@IncomeTypeId AND CategoryId=@CatThuong AND Note=N'Thưởng tháng ' + @MonthText
    );

    INSERT INTO Transactions(UserId, TypeId, CategoryId, TransactionDate, Amount, Note)
    SELECT @AdminId, @SavingTypeId, @CatTienMat, DATEFROMPARTS(@YearNo, @MonthNo, 10), 2500000 + ((@MonthNo % 4) * 250000), N'Tiết kiệm tiền mặt tháng ' + @MonthText
    WHERE NOT EXISTS (
        SELECT 1 FROM Transactions
        WHERE UserId=@AdminId AND TransactionDate=DATEFROMPARTS(@YearNo, @MonthNo, 10)
          AND TypeId=@SavingTypeId AND CategoryId=@CatTienMat AND Note=N'Tiết kiệm tiền mặt tháng ' + @MonthText
    );

    INSERT INTO Transactions(UserId, TypeId, CategoryId, TransactionDate, Amount, Note)
    SELECT @AdminId, @ExpenseTypeId, @CatAnUong, DATEFROMPARTS(@YearNo, @MonthNo, 4), 260000 + (@MonthNo * 12000), N'Ăn uống ngày 04/' + @MonthText
    WHERE NOT EXISTS (
        SELECT 1 FROM Transactions WHERE UserId=@AdminId AND TransactionDate=DATEFROMPARTS(@YearNo, @MonthNo, 4) AND Note=N'Ăn uống ngày 04/' + @MonthText
    );

    INSERT INTO Transactions(UserId, TypeId, CategoryId, TransactionDate, Amount, Note)
    SELECT @AdminId, @ExpenseTypeId, @CatDiLai, DATEFROMPARTS(@YearNo, @MonthNo, 16), 150000 + (@MonthNo * 8000), N'Đi lại ngày 16/' + @MonthText
    WHERE NOT EXISTS (
        SELECT 1 FROM Transactions WHERE UserId=@AdminId AND TransactionDate=DATEFROMPARTS(@YearNo, @MonthNo, 16) AND Note=N'Đi lại ngày 16/' + @MonthText
    );

    INSERT INTO Transactions(UserId, TypeId, CategoryId, TransactionDate, Amount, Note)
    SELECT @AdminId, @ExpenseTypeId, @CatMuaSam, DATEFROMPARTS(@YearNo, @MonthNo, 28), 350000 + (@MonthNo * 17000), N'Mua sắm ngày 28/' + @MonthText
    WHERE NOT EXISTS (
        SELECT 1 FROM Transactions WHERE UserId=@AdminId AND TransactionDate=DATEFROMPARTS(@YearNo, @MonthNo, 28) AND Note=N'Mua sắm ngày 28/' + @MonthText
    );

    SET @CurrentMonth = DATEADD(MONTH, 1, @CurrentMonth);
END;

IF NOT EXISTS (SELECT 1 FROM SavingsGoals WHERE UserId=@User01Id AND GoalName=N'Quỹ dự phòng user01')
BEGIN
    INSERT INTO SavingsGoals(UserId, GoalName, TargetAmount, MonthlyBudget, StartDate, TargetDate, IsActive)
    VALUES (@User01Id, N'Quỹ dự phòng user01', 25000000, 7500000, '2025-01-01', '2026-06-30', 1);
END;

IF NOT EXISTS (SELECT 1 FROM SavingsGoals WHERE UserId=@User01Id AND GoalName=N'Mua laptop user01')
BEGIN
    INSERT INTO SavingsGoals(UserId, GoalName, TargetAmount, MonthlyBudget, StartDate, TargetDate, IsActive)
    VALUES (@User01Id, N'Mua laptop user01', 18000000, 7000000, '2025-06-01', '2026-12-31', 1);
END;

IF NOT EXISTS (SELECT 1 FROM SavingsGoals WHERE UserId=@AdminId AND GoalName=N'Quỹ du lịch admin')
BEGIN
    INSERT INTO SavingsGoals(UserId, GoalName, TargetAmount, MonthlyBudget, StartDate, TargetDate, IsActive)
    VALUES (@AdminId, N'Quỹ du lịch admin', 30000000, 12000000, '2025-01-01', '2026-06-30', 1);
END;

IF NOT EXISTS (SELECT 1 FROM SavingsGoals WHERE UserId=@AdminId AND GoalName=N'Quỹ đầu tư admin')
BEGIN
    INSERT INTO SavingsGoals(UserId, GoalName, TargetAmount, MonthlyBudget, StartDate, TargetDate, IsActive)
    VALUES (@AdminId, N'Quỹ đầu tư admin', 50000000, 15000000, '2025-06-01', '2026-12-31', 1);
END;
GO

SELECT Username, FullName, IsActive AS UserIsActive, IsAdmin
FROM Users
WHERE Username IN (N'admin', N'user01');

SELECT u.Username,
       COUNT(*) AS TotalTransactions,
       MIN(t.TransactionDate) AS FromDate,
       MAX(t.TransactionDate) AS ToDate
FROM Transactions t
INNER JOIN Users u ON t.UserId = u.UserId
WHERE u.Username IN (N'admin', N'user01')
GROUP BY u.Username
ORDER BY u.Username;

SELECT u.Username,
       g.GoalName,
       g.TargetAmount,
       g.MonthlyBudget,
       g.StartDate,
       g.TargetDate,
       g.IsActive AS GoalIsActive
FROM SavingsGoals g
INNER JOIN Users u ON g.UserId = u.UserId
WHERE u.Username IN (N'admin', N'user01')
ORDER BY u.Username, g.GoalId;
GO
