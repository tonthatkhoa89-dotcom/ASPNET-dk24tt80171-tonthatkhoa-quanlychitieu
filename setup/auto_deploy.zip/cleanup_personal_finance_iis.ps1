﻿param(
  [string]$SiteName = "PersonalFinanceOffline",
  [string]$AppPoolName = "PersonalFinanceOffline",
  [string]$DeployPath = "C:\inetpub\wwwroot\PersonalFinanceOffline",
  [string]$SqlServer = "",
  [string]$DatabaseName = "PersonalFinanceDb",
  [switch]$UseSqlLogin,
  [string]$SqlUser = "",
  [string]$SqlPassword = "",
  [string]$SqlDataPath = "",
  [string]$WebConfigPath = "",
  [switch]$DisableSqlAutoDetect,
  [switch]$SkipWebConfigSqlDetect,
  [switch]$UseDatabaseFromWebConfig,
  [switch]$SkipSqlInstancePrompt,
  [switch]$DeleteBackups,
  [switch]$Force,
  [switch]$FailOnError
)

$ErrorActionPreference = "Stop"

$script:CleanupResults = New-Object System.Collections.Generic.List[object]
$script:CurrentTaskMessage = ""
$script:DetectedWebConfigSql = $null
$script:DetectedSqlInstances = @()
$script:SelectedSqlInfo = $null
$script:EffectiveSqlServer = $SqlServer
$script:EffectiveDatabaseName = $DatabaseName
$script:ResolvedSqlDataPath = ""
$script:DatabaseNameWasProvided = $PSBoundParameters.ContainsKey("DatabaseName")

function Add-CleanupResult {
  param(
    [string]$Task,
    [string]$Status,
    [string]$Message = ""
  )

  $script:CleanupResults.Add([pscustomobject]@{
    Task    = $Task
    Status  = $Status
    Message = $Message
  }) | Out-Null
}

function Set-TaskMessage {
  param([string]$Message)
  $script:CurrentTaskMessage = $Message
}

function Invoke-CleanupTask {
  param(
    [string]$Name,
    [scriptblock]$Action
  )

  $script:CurrentTaskMessage = ""
  try {
    & $Action
    Add-CleanupResult -Task $Name -Status "COMPLETED" -Message $script:CurrentTaskMessage
    return $true
  }
  catch {
    $msg = $_.Exception.Message
    Write-Host ""
    Write-Host "[FAILED] $Name" -ForegroundColor Red
    Write-Host $msg -ForegroundColor Red
    Write-Host "Bo qua task nay va tiep tuc cleanup..." -ForegroundColor Yellow
    Add-CleanupResult -Task $Name -Status "FAILED" -Message $msg
    return $false
  }
}

function Add-SkippedCleanupTask {
  param(
    [string]$Name,
    [string]$Message = ""
  )
  Write-Host ""
  Write-Host "[SKIPPED] $Name" -ForegroundColor Yellow
  if(-not [string]::IsNullOrWhiteSpace($Message)){ Write-Host $Message -ForegroundColor Yellow }
  Add-CleanupResult -Task $Name -Status "SKIPPED" -Message $Message
}

function Show-CleanupChecklist {
  Step "CLEANUP CHECKLIST"

  $completed = @($script:CleanupResults | Where-Object { $_.Status -eq "COMPLETED" })
  $failed    = @($script:CleanupResults | Where-Object { $_.Status -eq "FAILED" })
  $skipped   = @($script:CleanupResults | Where-Object { $_.Status -eq "SKIPPED" })

  foreach($r in $script:CleanupResults){
    $suffix = ""
    if(-not [string]::IsNullOrWhiteSpace($r.Message)){ $suffix = " - " + $r.Message }

    if($r.Status -eq "COMPLETED"){
      Write-Host ("[COMPLETED] " + $r.Task + $suffix) -ForegroundColor Green
    }
    elseif($r.Status -eq "FAILED"){
      Write-Host ("[FAILED]    " + $r.Task + $suffix) -ForegroundColor Red
    }
    else {
      Write-Host ("[SKIPPED]   " + $r.Task + $suffix) -ForegroundColor Yellow
    }
  }

  Write-Host ""
  Write-Host ("Completed: {0} | Failed: {1} | Skipped: {2}" -f $completed.Count, $failed.Count, $skipped.Count) -ForegroundColor Cyan
}

function Step($m){ Write-Host ""; Write-Host "=== $m ===" -ForegroundColor Cyan }

function Assert-Admin {
  $id=[Security.Principal.WindowsIdentity]::GetCurrent()
  $p=New-Object Security.Principal.WindowsPrincipal($id)
  if(-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
    throw "Vui long chay PowerShell bang Run as Administrator."
  }
}

function Find-SqlCmd {
  $cmd=Get-Command sqlcmd.exe -ErrorAction SilentlyContinue
  if($cmd){ return $cmd.Source }
  $paths=@(
    "C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\180\Tools\Binn\sqlcmd.exe",
    "C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn\sqlcmd.exe",
    "C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\130\Tools\Binn\sqlcmd.exe",
    "C:\Program Files\Microsoft SQL Server\160\Tools\Binn\sqlcmd.exe",
    "C:\Program Files\Microsoft SQL Server\150\Tools\Binn\sqlcmd.exe",
    "C:\Program Files\Microsoft SQL Server\140\Tools\Binn\sqlcmd.exe",
    "C:\Program Files\Microsoft SQL Server\110\Tools\Binn\sqlcmd.exe"
  )
  foreach($p in $paths){ if(Test-Path $p){ return $p } }
  throw "Khong tim thay sqlcmd.exe. Hay cai SQL Server Command Line Utilities hoac chay drop database bang SSMS."
}

function Invoke-SqlText {
  param([string]$Text,[string]$Server,[bool]$UseLogin=$false,[string]$User="",[string]$Password="")
  $sqlcmd=Find-SqlCmd
  $args=@("-S",$Server,"-b","-Q",$Text)
  if($UseLogin){
    if([string]::IsNullOrWhiteSpace($User) -or [string]::IsNullOrWhiteSpace($Password)){ throw "Thieu SqlUser/SqlPassword." }
    $args += @("-U",$User,"-P",$Password)
  } else {
    $args += @("-E")
  }
  & $sqlcmd @args
  if($LASTEXITCODE -ne 0){ throw "Chay SQL loi. Server=$Server ExitCode=$LASTEXITCODE" }
}

function Invoke-SqlScalar {
  param([string]$Text,[string]$Server,[bool]$UseLogin=$false,[string]$User="",[string]$Password="")
  $sqlcmd=Find-SqlCmd
  $args=@("-S",$Server,"-b","-h","-1","-W","-Q",$Text)
  if($UseLogin){ $args += @("-U",$User,"-P",$Password) } else { $args += @("-E") }
  $out=& $sqlcmd @args 2>$null
  if($LASTEXITCODE -ne 0){ return "" }
  return (($out | Where-Object { $_ -and $_.Trim() -ne "" }) -join "`n").Trim()
}

function Normalize-SqlServerName {
  param([string]$Server)

  if([string]::IsNullOrWhiteSpace($Server)){ return "" }

  $s = $Server.Trim()
  $localNames = @(".", "localhost", "127.0.0.1", "(local)", $env:COMPUTERNAME)

  foreach($local in $localNames){
    # MSSQLSERVER la default instance, khong ket noi bang .\MSSQLSERVER.
    # Chuoi dung cho default instance la . hoac localhost.
    if($s -ieq "$local\MSSQLSERVER"){
      return "."
    }
  }

  if($s -ieq "MSSQLSERVER"){ return "." }
  if($s -ieq "SQLEXPRESS"){ return ".\SQLEXPRESS" }

  return $s
}


function Convert-UserSqlInstanceInputToServerName {
  param([string]$InputValue)

  if([string]::IsNullOrWhiteSpace($InputValue)){ return "" }

  $s = $InputValue.Trim()

  # Cho phep nhap truc tiep server day du, vi du: .\SQLEXPRESS, localhost\SQLEXPRESS, SERVER\INSTANCE.
  if($s -match "\\"){
    return (Normalize-SqlServerName -Server $s)
  }

  # Default instance cua SQL Server co service MSSQLSERVER, nhung connection string phai dung ".".
  foreach($local in @(".", "localhost", "127.0.0.1", "(local)", $env:COMPUTERNAME)){
    if($s -ieq $local){ return (Normalize-SqlServerName -Server $s) }
  }

  if($s -ieq "MSSQLSERVER"){ return "." }

  # Neu user copy ten service, vi du MSSQL$SQLEXPRESS, convert ve .\SQLEXPRESS.
  if($s -like "MSSQL`$*"){
    $serverFromService = ConvertTo-ServerNameFromServiceName -ServiceName $s
    if(-not [string]::IsNullOrWhiteSpace($serverFromService)){ return $serverFromService }
  }

  # Khi user chi nhap ten instance local, vi du SQLEXPRESS hoac SQLEXPRESS01,
  # sqlcmd phai ket noi bang .\<InstanceName>.
  return ".\$s"
}

function Prompt-SqlServerInput {
  param(
    [string]$CurrentSqlServer,
    [bool]$SkipPrompt=$false
  )

  if($SkipPrompt){
    Set-TaskMessage "Skipped SQL instance prompt"
    return $CurrentSqlServer
  }

  Step "Nhap SQL instance"

  $currentDisplay = $CurrentSqlServer
  if([string]::IsNullOrWhiteSpace($currentDisplay)){
    $currentDisplay = "auto-detect instance dang chay"
  }
  else {
    $currentDisplay = Normalize-SqlServerName -Server $currentDisplay
  }

  Write-Host "Nhap ten SQL instance/server de cleanup database." -ForegroundColor Cyan
  Write-Host "Vi du:" -ForegroundColor Cyan
  Write-Host "  - SQLEXPRESS      => .\SQLEXPRESS" -ForegroundColor Gray
  Write-Host "  - SQLEXPRESS01    => .\SQLEXPRESS01" -ForegroundColor Gray
  Write-Host "  - MSSQLSERVER     => .  (default instance)" -ForegroundColor Gray
  Write-Host "  - .\SQLEXPRESS    => dung truc tiep" -ForegroundColor Gray
  Write-Host "Enter de trong     => dung mac dinh: $currentDisplay" -ForegroundColor Yellow

  try {
    $localServices = @(Get-LocalSqlInstanceServices)
    if($localServices.Count -gt 0){
      Write-Host ""
      Write-Host "SQL service local dang phat hien:" -ForegroundColor Cyan
      foreach($svc in $localServices){
        Write-Host (" - {0,-22} Instance={1,-18} Server={2,-20} Status={3}" -f $svc.ServiceName,$svc.InstanceName,$svc.ServerName,$svc.Status) -ForegroundColor Gray
      }
    }
  }
  catch {}

  Write-Host ""
  try {
    $inputValue = Read-Host "Nhap SQL instance/server"
  }
  catch {
    Write-Host "Khong doc duoc input tu console. Se dung mac dinh: $currentDisplay" -ForegroundColor Yellow
    Set-TaskMessage "Cannot read console input; use default=$currentDisplay"
    return $CurrentSqlServer
  }

  if([string]::IsNullOrWhiteSpace($inputValue)){
    Write-Host "Khong nhap SQL instance. Dung mac dinh: $currentDisplay" -ForegroundColor Yellow
    Set-TaskMessage "Empty input; use default=$currentDisplay"
    return $CurrentSqlServer
  }

  $serverName = Convert-UserSqlInstanceInputToServerName -InputValue $inputValue
  Write-Host "SQL Server se dung: $serverName" -ForegroundColor Green
  Set-TaskMessage "User input=$inputValue, normalized=$serverName"
  return $serverName
}

function ConvertTo-ServerNameFromServiceName {
  param([string]$ServiceName)

  if($ServiceName -eq "MSSQLSERVER"){
    return "."
  }

  if($ServiceName -like "MSSQL`$*"){
    $instance = $ServiceName.Substring(6)
    return ".\$instance"
  }

  return ""
}

function Get-LocalSqlInstanceServices {
  $items = @()

  try {
    $services = Get-Service -ErrorAction Stop | Where-Object {
      $_.Name -eq "MSSQLSERVER" -or $_.Name -like "MSSQL`$*"
    }
  }
  catch {
    return @()
  }

  foreach($svc in $services){
    $serverName = ConvertTo-ServerNameFromServiceName -ServiceName $svc.Name
    if([string]::IsNullOrWhiteSpace($serverName)){ continue }

    $instanceName = "MSSQLSERVER"
    $isDefault = $true
    $priority = 2

    if($svc.Name -like "MSSQL`$*"){
      $instanceName = $svc.Name.Substring(6)
      $isDefault = $false
      $priority = 3
      if($instanceName -ieq "SQLEXPRESS"){ $priority = 1 }
    }

    $startType = "Unknown"
    try { $startType = $svc.StartType.ToString() } catch {}

    $items += [pscustomobject]@{
      ServiceName  = $svc.Name
      InstanceName = $instanceName
      ServerName   = $serverName
      Status       = $svc.Status.ToString()
      StartType    = $startType
      IsDefault    = $isDefault
      Priority     = $priority
    }
  }

  return @($items | Sort-Object @{Expression={ if($_.Status -eq "Running"){0}else{1} }}, Priority, InstanceName)
}

function Parse-ConnectionStringText {
  param([string]$ConnectionString)

  if([string]::IsNullOrWhiteSpace($ConnectionString)){ return $null }

  try {
    $builder = New-Object System.Data.Common.DbConnectionStringBuilder
    $builder.ConnectionString = $ConnectionString

    $server = ""
    foreach($k in @("Data Source","Server","Address","Addr","Network Address")){
      if($builder.ContainsKey($k)){ $server = [string]$builder[$k]; break }
    }

    $db = ""
    foreach($k in @("Initial Catalog","Database")){
      if($builder.ContainsKey($k)){ $db = [string]$builder[$k]; break }
    }

    if([string]::IsNullOrWhiteSpace($server) -and [string]::IsNullOrWhiteSpace($db)){ return $null }

    return [pscustomobject]@{
      Server = $server
      Database = $db
      ConnectionString = $ConnectionString
    }
  }
  catch {
    return $null
  }
}

function Get-WebConfigCandidates {
  param([string]$DeployPath,[string]$InputWebConfigPath)

  $candidates = @()

  if(-not [string]::IsNullOrWhiteSpace($InputWebConfigPath)){
    $candidates += $InputWebConfigPath
  }

  if(-not [string]::IsNullOrWhiteSpace($DeployPath)){
    $candidates += (Join-Path $DeployPath "backend\Web.config")
    $candidates += (Join-Path $DeployPath "backend\web.config")
    $candidates += (Join-Path $DeployPath "Web.config")
    $candidates += (Join-Path $DeployPath "web.config")
  }

  $unique = @()
  foreach($c in $candidates){
    if(-not [string]::IsNullOrWhiteSpace($c) -and -not ($unique -contains $c)){
      $unique += $c
    }
  }
  return $unique
}

function Read-SqlInfoFromWebConfig {
  param([string]$DeployPath,[string]$InputWebConfigPath,[string]$PreferredDb)

  $paths = Get-WebConfigCandidates -DeployPath $DeployPath -InputWebConfigPath $InputWebConfigPath
  foreach($path in $paths){
    if(-not (Test-Path $path)){ continue }

    try {
      [xml]$xml = Get-Content -Path $path -Raw -ErrorAction Stop
      $adds = @($xml.configuration.connectionStrings.add)
      $found = @()

      foreach($add in $adds){
        $cs = [string]$add.connectionString
        if([string]::IsNullOrWhiteSpace($cs)){ continue }
        $parsed = Parse-ConnectionStringText -ConnectionString $cs
        if($null -eq $parsed){ continue }

        $score = 0
        $name = [string]$add.name
        if($name -match "Finance|Default|Connection|Personal"){ $score += 5 }
        if(-not [string]::IsNullOrWhiteSpace($parsed.Database)){
          $score += 5
          if($parsed.Database -eq $PreferredDb){ $score += 10 }
          if($parsed.Database -match "PersonalFinance"){ $score += 5 }
        }
        if(-not [string]::IsNullOrWhiteSpace($parsed.Server)){ $score += 5 }

        $found += [pscustomobject]@{
          Name = $name
          Path = $path
          Server = $parsed.Server
          Database = $parsed.Database
          ConnectionString = $parsed.ConnectionString
          Score = $score
        }
      }

      if($found.Count -gt 0){
        return ($found | Sort-Object Score -Descending | Select-Object -First 1)
      }
    }
    catch {
      Write-Host "Khong doc duoc Web.config: $path - $($_.Exception.Message)" -ForegroundColor Yellow
    }
  }

  return $null
}

function Invoke-SqlCmdRaw {
  param([string[]]$Arguments)

  # IMPORTANT:
  # Khong dung Start-Process -ArgumentList voi mang tham so trong Windows PowerShell 5.x
  # vi Start-Process se ghep thanh 1 chuoi va khong quote dung tham so -Q co khoang trang.
  # Ket qua la sqlcmd nhan tung phan cua cau SELECT thanh argument rieng va bao:
  # "Unexpected argument. Enter -? for help."
  # Dung call operator (&) voi splatting de PowerShell truyen moi phan tu trong mang
  # thanh 1 argument rieng, cau query -Q duoc giu nguyen.
  $sqlcmd = Find-SqlCmd

  $oldErrorActionPreference = $ErrorActionPreference
  $ErrorActionPreference = 'Continue'
  try {
    $output = & $sqlcmd @Arguments 2>&1
    $exitCode = $LASTEXITCODE

    $text = ""
    if($null -ne $output){
      $text = (($output | ForEach-Object { $_.ToString() }) -join "`n")
    }

    return [pscustomobject]@{
      ExitCode = $exitCode
      StdOut   = $text
      StdErr   = ""
    }
  }
  catch {
    return [pscustomobject]@{
      ExitCode = 1
      StdOut   = ""
      StdErr   = $_.Exception.Message
    }
  }
  finally {
    $ErrorActionPreference = $oldErrorActionPreference
  }
}

function Test-SqlConnection {
  param(
    [string]$Server,
    [bool]$UseLogin=$false,
    [string]$User="",
    [string]$Password=""
  )

  if([string]::IsNullOrWhiteSpace($Server)){
    return [pscustomobject]@{
      Success=$false; Server=$Server; ProductVersion=""; ProductLevel=""; Edition=""; InstanceName=""; Message="Empty SQL Server name"
    }
  }

  $serverToTest = Normalize-SqlServerName -Server $Server
  $query = "SET NOCOUNT ON; SELECT CONVERT(nvarchar(128), SERVERPROPERTY('ProductVersion')) + N'|' + CONVERT(nvarchar(128), SERVERPROPERTY('ProductLevel')) + N'|' + CONVERT(nvarchar(128), SERVERPROPERTY('Edition')) + N'|' + ISNULL(CONVERT(nvarchar(128), SERVERPROPERTY('InstanceName')), N'MSSQLSERVER');"
  $args = @("-S",$serverToTest,"-b","-l","5","-W","-h","-1","-Q",$query)

  if($UseLogin){
    if([string]::IsNullOrWhiteSpace($User) -or [string]::IsNullOrWhiteSpace($Password)){
      return [pscustomobject]@{
        Success        = $false
        Server         = $serverToTest
        ProductVersion = ""
        ProductLevel   = ""
        Edition        = ""
        InstanceName   = ""
        Message        = "Thieu SqlUser/SqlPassword de test ket noi SQL."
      }
    }
    $args += @("-U",$User,"-P",$Password)
  }
  else {
    $args += @("-E")
  }

  try {
    $raw = Invoke-SqlCmdRaw -Arguments $args
  }
  catch {
    return [pscustomobject]@{
      Success        = $false
      Server         = $serverToTest
      ProductVersion = ""
      ProductLevel   = ""
      Edition        = ""
      InstanceName   = ""
      Message        = $_.Exception.Message
    }
  }

  $message = (($raw.StdOut, $raw.StdErr | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }) -join "`n").Trim()

  if($raw.ExitCode -ne 0){
    return [pscustomobject]@{
      Success        = $false
      Server         = $serverToTest
      ProductVersion = ""
      ProductLevel   = ""
      Edition        = ""
      InstanceName   = ""
      Message        = $message
    }
  }

  $line = $raw.StdOut -split "`r?`n" |
    ForEach-Object { $_.Trim() } |
    Where-Object { -not [string]::IsNullOrWhiteSpace($_) -and $_ -notmatch "^-+$" -and $_ -notmatch "^\(\d+ rows? affected\)$" } |
    Select-Object -First 1

  if([string]::IsNullOrWhiteSpace($line)){
    return [pscustomobject]@{
      Success        = $false
      Server         = $serverToTest
      ProductVersion = ""
      ProductLevel   = ""
      Edition        = ""
      InstanceName   = ""
      Message        = "SQL connected but version query returned empty output. Raw output: $message"
    }
  }

  $parts = @($line -split "\|", 4)
  while($parts.Count -lt 4){ $parts += "" }

  return [pscustomobject]@{
    Success        = $true
    Server         = $serverToTest
    ProductVersion = $parts[0]
    ProductLevel   = $parts[1]
    Edition        = $parts[2]
    InstanceName   = $parts[3]
    Message        = $message
  }
}

function Resolve-SqlServerForCleanup {
  param(
    [string]$ConfiguredServer,
    [string]$ConfiguredDatabase,
    [string]$DeployPath,
    [string]$InputWebConfigPath,
    [bool]$UseLogin=$false,
    [string]$User="",
    [string]$Password="",
    [bool]$DisableAutoDetect=$false,
    [bool]$SkipWebConfigDetect=$false,
    [bool]$UseDbFromWebConfig=$false
  )

  Step "Check SQL Server instance / connection string"

  $webInfo = $null
  if(-not $SkipWebConfigDetect){
    $webInfo = Read-SqlInfoFromWebConfig -DeployPath $DeployPath -InputWebConfigPath $InputWebConfigPath -PreferredDb $ConfiguredDatabase
    $script:DetectedWebConfigSql = $webInfo
    if($null -ne $webInfo){
      $webServerNorm = Normalize-SqlServerName -Server $webInfo.Server
      Write-Host "Web.config       : $($webInfo.Path)" -ForegroundColor Cyan
      Write-Host "Connection name  : $($webInfo.Name)" -ForegroundColor Cyan
      Write-Host "Web.config server: $($webInfo.Server)" -ForegroundColor Cyan
      if($webServerNorm -ne $webInfo.Server){ Write-Host "Normalized server: $webServerNorm" -ForegroundColor Yellow }
      Write-Host "Web.config DB    : $($webInfo.Database)" -ForegroundColor Cyan
    } else {
      Write-Host "Khong tim thay connection string trong Web.config. Se dung tham so va SQL service dang chay." -ForegroundColor Yellow
    }
  }

  $services = @(Get-LocalSqlInstanceServices)
  $script:DetectedSqlInstances = $services
  if($services.Count -gt 0){
    Write-Host "Detected local SQL Server services:" -ForegroundColor Cyan
    foreach($svc in $services){
      Write-Host (" - {0,-22} Instance={1,-18} Server={2,-20} Status={3,-8} StartType={4}" -f $svc.ServiceName,$svc.InstanceName,$svc.ServerName,$svc.Status,$svc.StartType)
    }
  } else {
    Write-Host "Khong tim thay SQL Server service local nao theo dang MSSQLSERVER hoac MSSQL`$<INSTANCE>." -ForegroundColor Yellow
  }

  $targets = @()

  if($DisableAutoDetect){
    $normalizedConfigured = Normalize-SqlServerName -Server $ConfiguredServer
    if(-not [string]::IsNullOrWhiteSpace($normalizedConfigured)){
      $targets += [pscustomobject]@{ Server=$normalizedConfigured; Source="Configured parameter -SqlServer (auto detect disabled)" }
    }
  }
  else {
    # Uu tien instance local dang Running. Cach nay tranh loi khi tham so mac dinh/Web.config con tro den instance cu da bi go cai dat.
    foreach($svc in @($services | Where-Object { $_.Status -eq "Running" })){
      $targets += [pscustomobject]@{ Server=$svc.ServerName; Source="Running SQL service $($svc.ServiceName)" }
    }

    if($null -ne $webInfo -and -not [string]::IsNullOrWhiteSpace($webInfo.Server)){
      $targets += [pscustomobject]@{ Server=(Normalize-SqlServerName -Server $webInfo.Server); Source="Web.config connection string" }
    }

    if(-not [string]::IsNullOrWhiteSpace($ConfiguredServer)){
      $targets += [pscustomobject]@{ Server=(Normalize-SqlServerName -Server $ConfiguredServer); Source="Configured parameter -SqlServer" }
    }

    # Fallback khi Get-Service khong doc duoc service nhung SQL van co the connect duoc.
    foreach($fallback in @(".", ".\SQLEXPRESS", "localhost")){
      $targets += [pscustomobject]@{ Server=$fallback; Source="Fallback local SQL candidate" }
    }
  }

  $uniqueTargets = @()
  foreach($t in $targets){
    if([string]::IsNullOrWhiteSpace($t.Server)){ continue }
    if(-not (@($uniqueTargets | ForEach-Object { $_.Server.ToLowerInvariant() }) -contains $t.Server.ToLowerInvariant())){
      $uniqueTargets += $t
    }
  }

  if($uniqueTargets.Count -eq 0){
    throw "Khong co SQL Server candidate nao de thu ket noi. Hay cai SQL Server Express/Developer hoac chi dinh -SqlServer."
  }

  $errors = @()
  foreach($t in $uniqueTargets){
    Write-Host ""
    Write-Host "Test SQL connection: $($t.Server) [$($t.Source)]" -ForegroundColor Yellow
    $result = Test-SqlConnection -Server $t.Server -UseLogin:$UseLogin -User $User -Password $Password

    if($result.Success){
      $script:EffectiveSqlServer = $result.Server
      $script:SelectedSqlInfo = $result

      if($UseDbFromWebConfig -or (-not $script:DatabaseNameWasProvided)){
        if($null -ne $webInfo -and -not [string]::IsNullOrWhiteSpace($webInfo.Database)){
          $script:EffectiveDatabaseName = $webInfo.Database
        } else {
          $script:EffectiveDatabaseName = $ConfiguredDatabase
        }
      } else {
        $script:EffectiveDatabaseName = $ConfiguredDatabase
      }

      Write-Host "Selected SQL Server : $($result.Server)" -ForegroundColor Green
      Write-Host "SQL Instance        : $($result.InstanceName)" -ForegroundColor Green
      Write-Host "SQL Version         : $($result.ProductVersion) $($result.ProductLevel)" -ForegroundColor Green
      Write-Host "SQL Edition         : $($result.Edition)" -ForegroundColor Green
      Write-Host "Cleanup Database    : $script:EffectiveDatabaseName" -ForegroundColor Green

      Set-TaskMessage ("Selected SQL Server=$($result.Server), DB=$script:EffectiveDatabaseName, Version=$($result.ProductVersion), Edition=$($result.Edition)")
      return $true
    }

    Write-Host "Khong ket noi duoc: $($t.Server)" -ForegroundColor Red
    if(-not [string]::IsNullOrWhiteSpace($result.Message)){
      Write-Host $result.Message -ForegroundColor DarkRed
    }
    $errors += ("{0} [{1}]: {2}" -f $t.Server, $t.Source, $result.Message)
  }

  $running = @($services | Where-Object { $_.Status -eq "Running" })
  $installed = @($services)

  $msg = "Khong ket noi duoc SQL Server nao."
  if($running.Count -eq 0 -and $installed.Count -gt 0){
    $msg += " Co SQL service nhung chua Running. Hay start SQL service truoc khi cleanup."
  }
  elseif($installed.Count -eq 0){
    $msg += " Khong tim thay SQL Server local. Hay cai SQL Server Express/Developer truoc."
  }
  if($errors.Count -gt 0){
    $msg += "`nChi tiet:`n" + ($errors -join "`n")
  }
  throw $msg
}

function Stop-And-Remove-IIS {
  param([string]$Name,[string]$Pool)
  Step "Stop va xoa IIS site/app pool"
  Import-Module WebAdministration -ErrorAction Stop

  if(Test-Path "IIS:\Sites\$Name"){
    try {
      Write-Host "Stop website: $Name" -ForegroundColor Yellow
      Stop-Website -Name $Name -ErrorAction SilentlyContinue
    } catch {}

    Write-Host "Remove website: $Name" -ForegroundColor Yellow
    Remove-Website -Name $Name
  } else {
    Write-Host "Khong thay website: $Name"
  }

  if(Test-Path "IIS:\AppPools\$Pool"){
    try {
      Write-Host "Stop app pool: $Pool" -ForegroundColor Yellow
      Stop-WebAppPool -Name $Pool -ErrorAction SilentlyContinue
    } catch {}

    Write-Host "Remove app pool: $Pool" -ForegroundColor Yellow
    Remove-WebAppPool -Name $Pool
  } else {
    Write-Host "Khong thay app pool: $Pool"
  }
}

function Drop-Database {
  param([string]$Server,[string]$Db,[bool]$UseLogin=$false,[string]$User="",[string]$Password="")
  Step "Drop database tren SQL Server"
  $safeDb = $Db.Replace("]","]]" )
  $sql=@"
IF DB_ID(N'$Db') IS NOT NULL
BEGIN
    ALTER DATABASE [$safeDb] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE [$safeDb];
    PRINT N'Dropped database: $Db';
END
ELSE
BEGIN
    PRINT N'Database does not exist: $Db';
END
"@
  Invoke-SqlText -Text $sql -Server $Server -UseLogin:$UseLogin -User $User -Password $Password
  Set-TaskMessage "Server=$Server, Database=$Db"
}

function Resolve-SqlDataPath {
  param([string]$Server,[string]$InputPath,[bool]$UseLogin=$false,[string]$User="",[string]$Password="")
  if(-not [string]::IsNullOrWhiteSpace($InputPath)){ return $InputPath }

  $fromSql = Invoke-SqlScalar -Text "SET NOCOUNT ON; SELECT CONVERT(nvarchar(4000), SERVERPROPERTY('InstanceDefaultDataPath'));" -Server $Server -UseLogin:$UseLogin -User $User -Password $Password
  if(-not [string]::IsNullOrWhiteSpace($fromSql) -and (Test-Path $fromSql)){ return $fromSql.TrimEnd('\') }

  $candidates = @()
  $candidates += Get-ChildItem "C:\Program Files\Microsoft SQL Server" -Directory -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -like "MSSQL*.*" } |
    ForEach-Object { Join-Path $_.FullName "MSSQL\DATA" }

  foreach($p in $candidates){ if(Test-Path $p){ return $p } }
  return ""
}

function Delete-Orphan-DbFiles {
  param([string]$DataPath,[string]$Db)
  Step "Xoa file MDF/LDF con sot trong MSSQL\\DATA"
  if([string]::IsNullOrWhiteSpace($DataPath)){
    Write-Host "Khong xac dinh duoc SqlDataPath. Bo qua buoc xoa file MDF/LDF." -ForegroundColor Yellow
    Set-TaskMessage "Skipped MDF/LDF delete because SqlDataPath is empty"
    return
  }
  if(-not (Test-Path $DataPath)){
    Write-Host "SqlDataPath khong ton tai: $DataPath. Bo qua." -ForegroundColor Yellow
    Set-TaskMessage "Skipped MDF/LDF delete because path does not exist: $DataPath"
    return
  }

  Write-Host "SqlDataPath: $DataPath"
  $patterns=@("$Db.mdf", "$Db.ldf", "$Db`_log.ldf", "$Db*.mdf", "$Db*.ldf")
  $files=@()
  foreach($pattern in $patterns){
    $files += Get-ChildItem -Path $DataPath -Filter $pattern -File -ErrorAction SilentlyContinue
  }
  $files = $files | Sort-Object FullName -Unique

  if(-not $files -or $files.Count -eq 0){
    Write-Host "Khong tim thay file MDF/LDF cua database $Db trong $DataPath"
    Set-TaskMessage "No MDF/LDF files found in $DataPath"
    return
  }

  foreach($f in $files){
    Write-Host "Delete: $($f.FullName)" -ForegroundColor Yellow
    Remove-Item $f.FullName -Force -ErrorAction Stop
  }
  Set-TaskMessage ("Deleted {0} file(s) in {1}" -f $files.Count,$DataPath)
}

function Delete-Source {
  param([string]$Path,[bool]$DeleteBackup)
  Step "Xoa source trong wwwroot"
  if(Test-Path $Path){
    Write-Host "Delete deploy path: $Path" -ForegroundColor Yellow
    Remove-Item $Path -Recurse -Force -ErrorAction Stop
  } else {
    Write-Host "Khong thay deploy path: $Path"
  }

  $backupCount = 0
  if($DeleteBackup){
    $parent=Split-Path $Path -Parent
    $leaf=Split-Path $Path -Leaf
    if(Test-Path $parent){
      $backupPattern="$leaf.backup_*"
      $backups=Get-ChildItem -Path $parent -Filter $backupPattern -Directory -ErrorAction SilentlyContinue
      foreach($b in $backups){
        Write-Host "Delete backup: $($b.FullName)" -ForegroundColor Yellow
        Remove-Item $b.FullName -Recurse -Force -ErrorAction Stop
        $backupCount++
      }
    }
  }

  Set-TaskMessage "DeployPath=$Path, DeletedBackups=$backupCount"
}

try {
  Step "Cleanup info"
  Write-Host "SiteName             : $SiteName"
  Write-Host "AppPoolName          : $AppPoolName"
  Write-Host "DeployPath           : $DeployPath"
  Write-Host "SqlServer input      : $SqlServer"
  Write-Host "DatabaseName input   : $DatabaseName"
  Write-Host "SqlDataPath          : $SqlDataPath"
  Write-Host "WebConfigPath        : $WebConfigPath"
  Write-Host "DisableSqlAutoDetect : $DisableSqlAutoDetect"
  Write-Host "SkipWebConfigSqlDetect: $SkipWebConfigSqlDetect"
  Write-Host "UseDatabaseFromWebConfig: $UseDatabaseFromWebConfig"
  Write-Host "SkipSqlInstancePrompt: $SkipSqlInstancePrompt"
  Write-Host "DeleteBackups        : $DeleteBackups"
  Write-Host "Force                : $Force"
  Write-Host "FailOnError          : $FailOnError"

  Invoke-CleanupTask -Name "SQL instance input" -Action {
    $script:EffectiveSqlServer = Prompt-SqlServerInput -CurrentSqlServer $SqlServer -SkipPrompt:$SkipSqlInstancePrompt
    $script:EffectiveSqlServer = Normalize-SqlServerName -Server $script:EffectiveSqlServer
    $script:EffectiveSqlServer = $script:EffectiveSqlServer.Trim()
    $script:EffectiveSqlServer = if([string]::IsNullOrWhiteSpace($script:EffectiveSqlServer)){ $SqlServer } else { $script:EffectiveSqlServer }
    $script:SqlServerFromPrompt = $script:EffectiveSqlServer
  } | Out-Null

  Write-Host "SqlServer effective  : $script:EffectiveSqlServer" -ForegroundColor Cyan

  if(-not $Force){
    Write-Host ""
    Write-Host "CANH BAO: Script se xoa IIS site/app pool, drop database va xoa source." -ForegroundColor Red
    Write-Host "Script se tu tim Web.config/SQL instance dang chay de drop database neu bat auto-detect." -ForegroundColor Yellow
    $confirm=Read-Host "Nhap YES de tiep tuc"
    if($confirm -ne "YES"){
      Add-CleanupResult -Task "User confirmation" -Status "SKIPPED" -Message "Nguoi dung huy cleanup"
      Show-CleanupChecklist
      Write-Host "Da huy cleanup."
      exit 0
    }
  } else {
    Add-CleanupResult -Task "User confirmation" -Status "COMPLETED" -Message "Force mode"
  }

  Invoke-CleanupTask -Name "Admin permission check" -Action {
    Assert-Admin
  } | Out-Null

  $sqlResolved = Invoke-CleanupTask -Name "Resolve SQL Server instance" -Action {
    Resolve-SqlServerForCleanup `
      -ConfiguredServer $script:EffectiveSqlServer `
      -ConfiguredDatabase $DatabaseName `
      -DeployPath $DeployPath `
      -InputWebConfigPath $WebConfigPath `
      -UseLogin:$UseSqlLogin `
      -User $SqlUser `
      -Password $SqlPassword `
      -DisableAutoDetect:$DisableSqlAutoDetect `
      -SkipWebConfigDetect:$SkipWebConfigSqlDetect `
      -UseDbFromWebConfig:$UseDatabaseFromWebConfig
  }

  Invoke-CleanupTask -Name "Stop IIS" -Action {
    Step "Stop IIS tam thoi"
    iisreset /stop | Out-Host
  } | Out-Null

  Invoke-CleanupTask -Name "Remove IIS site and app pool" -Action {
    Stop-And-Remove-IIS -Name $SiteName -Pool $AppPoolName
  } | Out-Null

  if($sqlResolved -and $null -ne $script:SelectedSqlInfo){
    Invoke-CleanupTask -Name "Drop SQL database" -Action {
      Drop-Database -Server $script:EffectiveSqlServer -Db $script:EffectiveDatabaseName -UseLogin:$UseSqlLogin -User $SqlUser -Password $SqlPassword
    } | Out-Null

    Invoke-CleanupTask -Name "Resolve SQL data path" -Action {
      $script:ResolvedSqlDataPath = Resolve-SqlDataPath -Server $script:EffectiveSqlServer -InputPath $SqlDataPath -UseLogin:$UseSqlLogin -User $SqlUser -Password $SqlPassword
      if([string]::IsNullOrWhiteSpace($script:ResolvedSqlDataPath)){
        Write-Host "Khong xac dinh duoc SqlDataPath. Buoc xoa file MDF/LDF se tu bo qua." -ForegroundColor Yellow
        Set-TaskMessage "SqlDataPath is empty"
      } else {
        Write-Host "Resolved SqlDataPath: $script:ResolvedSqlDataPath"
        Set-TaskMessage "SqlDataPath=$script:ResolvedSqlDataPath"
      }
    } | Out-Null

    Invoke-CleanupTask -Name "Delete orphan MDF/LDF files" -Action {
      Delete-Orphan-DbFiles -DataPath $script:ResolvedSqlDataPath -Db $script:EffectiveDatabaseName
    } | Out-Null
  }
  else {
    Add-SkippedCleanupTask -Name "Drop SQL database" -Message "Skipped because SQL Server instance was not resolved"
    Add-SkippedCleanupTask -Name "Resolve SQL data path" -Message "Skipped because SQL Server instance was not resolved"
    Add-SkippedCleanupTask -Name "Delete orphan MDF/LDF files" -Message "Skipped because SQL Server instance was not resolved"
  }

  Invoke-CleanupTask -Name "Delete deployed source and backups" -Action {
    Delete-Source -Path $DeployPath -DeleteBackup:$DeleteBackups
  } | Out-Null

  Invoke-CleanupTask -Name "Start IIS" -Action {
    Step "Start IIS"
    iisreset /start | Out-Host
  } | Out-Null

  Show-CleanupChecklist

  $failed = @($script:CleanupResults | Where-Object { $_.Status -eq "FAILED" })
  if($failed.Count -gt 0){
    Write-Host ""
    Write-Host "Cleanup da chay xong nhung co task failed. Xem checklist ben tren." -ForegroundColor Yellow
    if($FailOnError){ exit 1 }
    exit 0
  }

  Step "DONE"
  Write-Host "Da cleanup xong PersonalFinanceOffline." -ForegroundColor Green
  exit 0
}
catch {
  Write-Host ""
  Write-Host "CLEANUP SCRIPT ERROR" -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red

  Add-CleanupResult -Task "Unexpected script error" -Status "FAILED" -Message $_.Exception.Message

  try {
    Invoke-CleanupTask -Name "Start IIS after unexpected error" -Action {
      iisreset /start | Out-Host
    } | Out-Null
  } catch {}

  Show-CleanupChecklist

  if($FailOnError){ exit 1 }
  exit 0
}
