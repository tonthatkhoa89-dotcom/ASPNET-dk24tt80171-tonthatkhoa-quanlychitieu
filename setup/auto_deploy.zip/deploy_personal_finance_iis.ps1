﻿param(
  [string]$SourceZip = ".\PersonalFinanceOffline_FINAL.zip",
  [string]$SampleSql = ".\06_sample_data_2025_01_to_2026_06.sql",
  [string]$SiteName = "PersonalFinanceOffline",
  [string]$AppPoolName = "PersonalFinanceOffline",
  [string]$BackendAppPoolName = "PersonalFinanceOffline",
  [string]$DefaultWebSiteName = "Default Web Site",
  [switch]$SkipDefaultWebSiteBackendFinalCheck,
  [string]$DeployPath = "C:\inetpub\wwwroot\PersonalFinanceOffline",
  [int]$Port = 80,
  [string]$SqlServer = ".\SQLEXPRESS",
  [switch]$DisableSqlAutoDetect,
  [switch]$SkipSqlInstancePrompt,
  [string]$DatabaseName = "PersonalFinanceDb",
  [switch]$UseSqlLogin,
  [string]$SqlUser = "",
  [string]$SqlPassword = "",
  [switch]$RecreateDatabase,
  [switch]$ImportSampleData
)

$ErrorActionPreference = "Stop"


$script:DeployChecklist = [ordered]@{}

function Set-DeployCheck {
  param(
    [string]$Name,
    [string]$Status,
    [string]$Message = ""
  )
  $script:DeployChecklist[$Name] = [pscustomobject]@{
    Status  = $Status
    Message = $Message
  }
}

function Print-DeployChecklist {
  param([string]$Title = "DEPLOY CHECKLIST")

  Write-Host ""
  Write-Host "=== $Title ===" -ForegroundColor Cyan

  if($script:DeployChecklist.Count -eq 0){
    Write-Host "No checklist item recorded." -ForegroundColor Yellow
    return
  }

  foreach($key in $script:DeployChecklist.Keys){
    $item = $script:DeployChecklist[$key]
    $color = "White"
    $mark = "-"

    if($item.Status -eq "OK"){
      $color = "Green"
      $mark = "[OK]"
    }
    elseif($item.Status -eq "SKIP"){
      $color = "Yellow"
      $mark = "[SKIP]"
    }
    elseif($item.Status -eq "FAIL"){
      $color = "Red"
      $mark = "[FAIL]"
    }

    if([string]::IsNullOrWhiteSpace($item.Message)){
      Write-Host ("{0} {1}" -f $mark, $key) -ForegroundColor $color
    } else {
      Write-Host ("{0} {1}: {2}" -f $mark, $key, $item.Message) -ForegroundColor $color
    }
  }
}

function Step($m){ Write-Host ""; Write-Host "=== $m ===" -ForegroundColor Cyan }

function Assert-Admin {
  $id=[Security.Principal.WindowsIdentity]::GetCurrent()
  $p=New-Object Security.Principal.WindowsPrincipal($id)
  if(-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
    throw "Vui long chay PowerShell bang Run as Administrator."
  }
}

function Find-SqlCmd {
  $cmd=Get-Command sqlcmd.exe -ErrorAction SilentlyContinue
  if($cmd){ return $cmd.Source }
  $paths=@(
    "C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn\sqlcmd.exe",
    "C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\130\Tools\Binn\sqlcmd.exe",
    "C:\Program Files\Microsoft SQL Server\110\Tools\Binn\sqlcmd.exe"
  )
  foreach($p in $paths){ if(Test-Path $p){ return $p } }
  throw "Khong tim thay sqlcmd.exe. Hay cai SQL Server Command Line Utilities hoac chay SQL bang SSMS."
}


function Normalize-SqlServerName {
  param([string]$Server)

  if([string]::IsNullOrWhiteSpace($Server)){ return $Server }

  $s = $Server.Trim()
  $localNames = @(".", "localhost", "127.0.0.1", $env:COMPUTERNAME)

  foreach($local in $localNames){
    # MSSQLSERVER la default instance, khong ket noi bang .\MSSQLSERVER.
    # Chuoi dung cho default instance la . hoac localhost.
    if($s -ieq "$local\MSSQLSERVER"){
      return "."
    }
  }

  if($s -ieq "MSSQLSERVER"){
    return "."
  }

  if($s -ieq "SQLEXPRESS"){
    return ".\SQLEXPRESS"
  }

  return $s
}


function Convert-UserSqlInstanceInputToServerName {
  param([string]$InputValue)

  if([string]::IsNullOrWhiteSpace($InputValue)){ return "" }

  $s = $InputValue.Trim()

  # Cho phep nhap truc tiep server day du, vi du: .\SQLEXPRESS, localhost\SQLEXPRESS, SERVER\INSTANCE.
  if($s -match "\\"){
    return (Normalize-SqlServerName -Server $s)
  }

  # Default instance cua SQL Server co service MSSQLSERVER, nhung connection string phai dung ".".
  foreach($local in @(".", "localhost", "127.0.0.1", "(local)", $env:COMPUTERNAME)){
    if($s -ieq $local){ return (Normalize-SqlServerName -Server $s) }
  }

  if($s -ieq "MSSQLSERVER"){ return "." }

  # Neu user copy ten service, vi du MSSQL$SQLEXPRESS, convert ve .\SQLEXPRESS.
  if($s -like "MSSQL`$*"){
    $instance = $s.Substring(6)
    if([string]::IsNullOrWhiteSpace($instance)){ return "" }
    return ".\$instance"
  }

  # Khi user chi nhap ten instance local, vi du SQLEXPRESS hoac SQLEXPRESS01,
  # sqlcmd va connection string phai ket noi bang .\<InstanceName>.
  return ".\$s"
}

function Prompt-SqlServerInput {
  param(
    [string]$CurrentSqlServer,
    [bool]$SkipPrompt=$false
  )

  if($SkipPrompt){
    return $CurrentSqlServer
  }

  Step "Nhap SQL instance"

  $currentDisplay = $CurrentSqlServer
  if([string]::IsNullOrWhiteSpace($currentDisplay)){
    $currentDisplay = "auto-detect instance dang chay"
  }
  else {
    $currentDisplay = Normalize-SqlServerName -Server $currentDisplay
  }

  Write-Host "Nhap ten SQL instance/server de deploy database." -ForegroundColor Cyan
  Write-Host "Vi du:" -ForegroundColor Cyan
  Write-Host "  - SQLEXPRESS      => .\SQLEXPRESS" -ForegroundColor Gray
  Write-Host "  - SQLEXPRESS01    => .\SQLEXPRESS01" -ForegroundColor Gray
  Write-Host "  - MSSQLSERVER     => .  (default instance)" -ForegroundColor Gray
  Write-Host "  - .\SQLEXPRESS    => dung truc tiep" -ForegroundColor Gray
  Write-Host "Enter de trong     => dung mac dinh: $currentDisplay" -ForegroundColor Yellow

  try {
    $localServices = @(Get-LocalSqlInstanceCandidates)
    if($localServices.Count -gt 0){
      Write-Host ""
      Write-Host "SQL service local dang phat hien:" -ForegroundColor Cyan
      foreach($svc in $localServices){
        Write-Host (" - {0,-22} Instance={1,-18} Server={2,-20} Status={3}" -f $svc.ServiceName,$svc.InstanceName,$svc.Server,$svc.Status) -ForegroundColor Gray
      }
    }
  }
  catch {}

  Write-Host ""
  try {
    $inputValue = Read-Host "Nhap SQL instance/server"
  }
  catch {
    Write-Host "Khong doc duoc input tu console. Se dung mac dinh: $currentDisplay" -ForegroundColor Yellow
    return $CurrentSqlServer
  }

  if([string]::IsNullOrWhiteSpace($inputValue)){
    Write-Host "Khong nhap SQL instance. Dung mac dinh: $currentDisplay" -ForegroundColor Yellow
    return $CurrentSqlServer
  }

  $serverName = Convert-UserSqlInstanceInputToServerName -InputValue $inputValue
  if([string]::IsNullOrWhiteSpace($serverName)){
    Write-Host "Gia tri nhap khong hop le. Dung mac dinh: $currentDisplay" -ForegroundColor Yellow
    return $CurrentSqlServer
  }

  Write-Host "SQL Server se dung: $serverName" -ForegroundColor Green
  return $serverName
}

function Get-LocalSqlInstanceCandidates {
  $items = @()

  try {
    $services = Get-Service -ErrorAction Stop | Where-Object {
      $_.Name -eq "MSSQLSERVER" -or $_.Name -like "MSSQL`$*"
    }
  }
  catch {
    return @()
  }

  foreach($svc in $services){
    if($svc.Name -eq "MSSQLSERVER"){
      $items += [pscustomobject]@{
        ServiceName  = $svc.Name
        InstanceName = "MSSQLSERVER"
        Server       = "."
        Status       = $svc.Status.ToString()
        IsDefault    = $true
        Priority     = 2
      }
    }
    else {
      $instance = $svc.Name.Substring(6)
      $priority = 3
      if($instance -ieq "SQLEXPRESS"){
        $priority = 1
      }

      $items += [pscustomobject]@{
        ServiceName  = $svc.Name
        InstanceName = $instance
        Server       = ".\$instance"
        Status       = $svc.Status.ToString()
        IsDefault    = $false
        Priority     = $priority
      }
    }
  }

  return @($items | Sort-Object @{Expression={ if($_.Status -eq "Running"){0}else{1} }}, Priority, InstanceName)
}

function Test-SqlConnection {
  param(
    [string]$Server,
    [bool]$UseLogin=$false,
    [string]$User="",
    [string]$Password=""
  )

  $sqlcmd = Find-SqlCmd
  $query = "SET NOCOUNT ON; SELECT CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(50)) + N'|' + CAST(SERVERPROPERTY('ProductLevel') AS nvarchar(50)) + N'|' + CAST(SERVERPROPERTY('Edition') AS nvarchar(200)) + N'|' + ISNULL(CAST(SERVERPROPERTY('InstanceName') AS nvarchar(128)), N'MSSQLSERVER');"
  $args = @("-S",$Server,"-b","-C","-l","5","-W","-h","-1","-Q",$query)

  if($UseLogin){
    if([string]::IsNullOrWhiteSpace($User) -or [string]::IsNullOrWhiteSpace($Password)){
      return [pscustomobject]@{
        Success        = $false
        Server         = $Server
        ProductVersion = ""
        ProductLevel   = ""
        Edition        = ""
        InstanceName   = ""
        Message        = "Thieu SqlUser/SqlPassword de test ket noi SQL."
      }
    }
    $args += @("-U",$User,"-P",$Password)
  }
  else {
    $args += @("-E")
  }

  $raw = & $sqlcmd @args 2>&1
  $exitCode = $LASTEXITCODE
  $message = (($raw | ForEach-Object { $_.ToString() }) -join "`n").Trim()

  if($exitCode -ne 0){
    return [pscustomobject]@{
      Success        = $false
      Server         = $Server
      ProductVersion = ""
      ProductLevel   = ""
      Edition        = ""
      InstanceName   = ""
      Message        = $message
    }
  }

  $line = $raw |
    ForEach-Object { $_.ToString().Trim() } |
    Where-Object { -not [string]::IsNullOrWhiteSpace($_) -and $_ -notmatch "^-+$" -and $_ -notmatch "^\(\d+ rows? affected\)$" } |
    Select-Object -First 1

  $parts = @($line -split "\|", 4)
  while($parts.Count -lt 4){ $parts += "" }

  return [pscustomobject]@{
    Success        = $true
    Server         = $Server
    ProductVersion = $parts[0]
    ProductLevel   = $parts[1]
    Edition        = $parts[2]
    InstanceName   = $parts[3]
    Message        = $message
  }
}

function Resolve-SqlServerInstance {
  param(
    [string]$RequestedServer,
    [bool]$UseLogin=$false,
    [string]$User="",
    [string]$Password="",
    [bool]$DisableAutoDetect=$false
  )

  Step "Check SQL Server instance / version"

  $normalizedRequested = Normalize-SqlServerName -Server $RequestedServer
  if($normalizedRequested -ne $RequestedServer){
    Write-Host "Normalize SqlServer: '$RequestedServer' -> '$normalizedRequested'" -ForegroundColor Yellow
  }

  $instances = @(Get-LocalSqlInstanceCandidates)
  if($instances.Count -gt 0){
    Write-Host "Detected local SQL Server services:" -ForegroundColor Cyan
    foreach($i in $instances){
      Write-Host (" - {0,-22} Instance={1,-18} Server={2,-20} Status={3}" -f $i.ServiceName, $i.InstanceName, $i.Server, $i.Status)
    }
  }
  else {
    Write-Host "Khong tim thay service SQL Server local theo dang MSSQLSERVER hoac MSSQL`$<INSTANCE>." -ForegroundColor Yellow
  }

  $targets = @()
  if(-not [string]::IsNullOrWhiteSpace($normalizedRequested)){
    $targets += [pscustomobject]@{
      Server = $normalizedRequested
      Source = "configured parameter"
    }
  }

  if(-not $DisableAutoDetect){
    foreach($i in ($instances | Where-Object { $_.Status -eq "Running" })){
      if(@($targets | ForEach-Object { $_.Server }) -notcontains $i.Server){
        $targets += [pscustomobject]@{
          Server = $i.Server
          Source = "running service $($i.ServiceName)"
        }
      }
    }
  }

  $errors = @()
  foreach($t in $targets){
    Write-Host "Test SQL connection: $($t.Server) [$($t.Source)]" -ForegroundColor Yellow
    $result = Test-SqlConnection -Server $t.Server -UseLogin:$UseLogin -User $User -Password $Password

    if($result.Success){
      Write-Host "Selected SQL Server : $($result.Server)" -ForegroundColor Green
      Write-Host "SQL Instance        : $($result.InstanceName)" -ForegroundColor Green
      Write-Host "SQL Version         : $($result.ProductVersion) $($result.ProductLevel)" -ForegroundColor Green
      Write-Host "SQL Edition         : $($result.Edition)" -ForegroundColor Green
      return $result
    }

    Write-Host "Khong ket noi duoc: $($t.Server)" -ForegroundColor Red
    if(-not [string]::IsNullOrWhiteSpace($result.Message)){
      Write-Host $result.Message -ForegroundColor DarkRed
    }
    $errors += ("{0}: {1}" -f $t.Server, $result.Message)
  }

  $running = @($instances | Where-Object { $_.Status -eq "Running" })
  $installed = @($instances)

  $msg = "Khong ket noi duoc SQL Server."
  if($running.Count -eq 0 -and $installed.Count -gt 0){
    $msg += " Co SQL service nhung chua Running. Hay start SQL service truoc khi deploy."
  }
  elseif($installed.Count -eq 0){
    $msg += " Khong tim thay SQL Server local. Hay cai SQL Server Express/Developer truoc."
  }
  if($errors.Count -gt 0){
    $msg += "`nChi tiet:`n" + ($errors -join "`n")
  }
  throw $msg
}

function Invoke-SqlFile {
  param([string]$File,[string]$Server,[bool]$UseLogin=$false,[string]$User="",[string]$Password="")
  if(-not (Test-Path $File)){ throw "Khong tim thay SQL file: $File" }
  $sqlcmd=Find-SqlCmd
  $args=@("-S",$Server,"-b","-C","-i",$File)
  if($UseLogin){
    if([string]::IsNullOrWhiteSpace($User) -or [string]::IsNullOrWhiteSpace($Password)){ throw "Thieu SqlUser/SqlPassword." }
    $args += @("-U",$User,"-P",$Password)
  } else {
    $args += @("-E")
  }
  Write-Host "Run SQL: $File" -ForegroundColor Yellow
  & $sqlcmd @args
  if($LASTEXITCODE -ne 0){ throw "Chay SQL loi: $File" }
}

function Invoke-SqlText {
  param([string]$Text,[string]$Server,[bool]$UseLogin=$false,[string]$User="",[string]$Password="")
  $tmp=Join-Path $env:TEMP ("deploy_sql_"+[Guid]::NewGuid().ToString("N")+".sql")
  Set-Content $tmp $Text -Encoding UTF8
  try { Invoke-SqlFile -File $tmp -Server $Server -UseLogin:$UseLogin -User $User -Password $Password }
  finally { Remove-Item $tmp -Force -ErrorAction SilentlyContinue }
}

function Enable-IISFeatures {
  Step "Enable IIS / ASP.NET 4.x"
  $features=@(
    "IIS-WebServerRole","IIS-WebServer","IIS-CommonHttpFeatures","IIS-DefaultDocument",
    "IIS-StaticContent","IIS-HttpErrors","IIS-ApplicationDevelopment",
    "IIS-NetFxExtensibility45","IIS-ASPNET45","IIS-ISAPIExtensions","IIS-ISAPIFilter",
    "IIS-RequestFiltering","IIS-ManagementConsole"
  )
  foreach($f in $features){
    $enabled = dism /online /Get-FeatureInfo /FeatureName:$f 2>$null | Select-String "State : Enabled"
    if(-not $enabled){
      Write-Host "Enable feature: $f" -ForegroundColor Yellow
      dism /online /Enable-Feature /FeatureName:$f /All /NoRestart | Out-Host
    }
  }
}

function Patch-UseDb {
  param([string]$InFile,[string]$OutFile,[string]$Db)
  $c=Get-Content $InFile -Raw -Encoding UTF8
  $c=$c -replace "USE PersonalFinanceDb;","USE [$Db];"
  Set-Content $OutFile $c -Encoding UTF8
}

function Patch-CreateDb {
  param([string]$InFile,[string]$OutFile,[string]$Db,[bool]$DropFirst)
  $c=Get-Content $InFile -Raw -Encoding UTF8
  $c=$c -replace "CREATE DATABASE PersonalFinanceDb;","CREATE DATABASE [$Db];"
  $c=$c -replace "USE PersonalFinanceDb;","USE [$Db];"
  if($DropFirst){
    $prefix="IF DB_ID(N'$Db') IS NOT NULL`r`nBEGIN`r`n ALTER DATABASE [$Db] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;`r`n DROP DATABASE [$Db];`r`nEND`r`nGO`r`n`r`n"
    $c=$prefix+$c
  } else {
    $prefix="IF DB_ID(N'$Db') IS NOT NULL`r`nBEGIN`r`n PRINT N'Database da ton tai, bo qua tao moi.';`r`n RETURN;`r`nEND`r`nGO`r`n`r`n"
    $c=$prefix+$c
  }
  Set-Content $OutFile $c -Encoding UTF8
}

function Update-WebConfig {
  param([string]$Config,[string]$Server,[string]$Db,[bool]$UseLogin,[string]$User,[string]$Password)
  Step "Edit Web.config"
  if(-not (Test-Path $Config)){ throw "Khong tim thay Web.config: $Config" }
  [xml]$xml=Get-Content $Config -Encoding UTF8
  $node=$xml.configuration.connectionStrings.add | Where-Object { $_.name -eq "FinanceDb" }
  if(-not $node){ throw "Khong tim thay connection string FinanceDb." }
  if($UseLogin){
    $conn="Data Source=$Server;Initial Catalog=$Db;User ID=$User;Password=$Password;MultipleActiveResultSets=True;TrustServerCertificate=True"
  } else {
    $conn="Data Source=$Server;Initial Catalog=$Db;Integrated Security=True;MultipleActiveResultSets=True;TrustServerCertificate=True"
  }
  $node.connectionString=$conn
  $xml.Save($Config)
  Write-Host "FinanceDb = $conn" -ForegroundColor Green
}

function Deploy-Files {
  param([string]$Zip,[string]$Target)
  Step "Extract source"
  if(-not (Test-Path $Zip)){ throw "Khong tim thay source zip: $Zip" }
  if(Test-Path $Target){
    $backup="$Target.backup_$(Get-Date -Format yyyyMMdd_HHmmss)"
    Write-Host "Backup source cu: $backup" -ForegroundColor Yellow
    Rename-Item $Target (Split-Path $backup -Leaf)
  }
  New-Item $Target -ItemType Directory -Force | Out-Null
  $tmp=Join-Path $env:TEMP ("finance_extract_"+[Guid]::NewGuid().ToString("N"))
  New-Item $tmp -ItemType Directory -Force | Out-Null
  Expand-Archive $Zip $tmp -Force
  $root=Join-Path $tmp "PersonalFinanceOffline"
  if(-not (Test-Path $root)){ throw "Zip khong dung cau truc: can thu muc PersonalFinanceOffline." }
  Copy-Item (Join-Path $root "*") $Target -Recurse -Force
  Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
}

function Configure-IIS {
  param(
    [string]$Name,
    [string]$Pool,
    [string]$BackendPool,
    [string]$Path,
    [int]$ListenPort
  )

  Step "Configure IIS site/app pool"

  Import-Module WebAdministration -ErrorAction Stop

  $AppCmd = "$env:windir\System32\inetsrv\appcmd.exe"
  if(-not (Test-Path $AppCmd)){
    throw "Khong tim thay appcmd.exe. Hay bat IIS truoc khi deploy."
  }

  $BackendPath = Join-Path $Path "backend"
  if(-not (Test-Path $BackendPath)){
    throw "Khong tim thay thu muc backend: $BackendPath"
  }

  function Run-AppCmd {
    param([string[]]$Arguments)
    Write-Host "appcmd $($Arguments -join ' ')" -ForegroundColor DarkYellow
    & $AppCmd @Arguments
    if($LASTEXITCODE -ne 0){
      throw "Lenh appcmd loi. ExitCode=${LASTEXITCODE}. Lenh: appcmd $($Arguments -join ' ')"
    }
  }

  # AppPool cho site/frontend
  if(-not (Test-Path "IIS:\AppPools\$Pool")){
    New-WebAppPool -Name $Pool | Out-Null
  }
  Set-ItemProperty "IIS:\AppPools\$Pool" -Name managedRuntimeVersion -Value "v4.0"
  Set-ItemProperty "IIS:\AppPools\$Pool" -Name managedPipelineMode -Value "Integrated"
  Set-ItemProperty "IIS:\AppPools\$Pool" -Name processModel.identityType -Value "ApplicationPoolIdentity"

  # AppPool rieng cho backend
  if(-not (Test-Path "IIS:\AppPools\$BackendPool")){
    New-WebAppPool -Name $BackendPool | Out-Null
  }
  Set-ItemProperty "IIS:\AppPools\$BackendPool" -Name managedRuntimeVersion -Value "v4.0"
  Set-ItemProperty "IIS:\AppPools\$BackendPool" -Name managedPipelineMode -Value "Integrated"
  Set-ItemProperty "IIS:\AppPools\$BackendPool" -Name processModel.identityType -Value "ApplicationPoolIdentity"

  # Tao hoac cap nhat site rieng PersonalFinanceOffline
  if(Test-Path "IIS:\Sites\$Name"){
    Set-ItemProperty "IIS:\Sites\$Name" -Name physicalPath -Value $Path
    Set-ItemProperty "IIS:\Sites\$Name" -Name applicationPool -Value $Pool

    Get-WebBinding -Name $Name | ForEach-Object {
      Remove-WebBinding -Name $Name -Protocol $_.protocol -BindingInformation $_.bindingInformation
    }

    New-WebBinding -Name $Name -Protocol http -Port $ListenPort -IPAddress "*" | Out-Null
  } else {
    New-Website -Name $Name -PhysicalPath $Path -ApplicationPool $Pool -Port $ListenPort -Force | Out-Null
  }

  # Dam bao site root dung AppPool frontend/site
  Set-ItemProperty "IIS:\Sites\$Name" -Name applicationPool -Value $Pool

  # Grant quyen doc source cho AppPool. Thuc hien truoc khi convert backend
  # de tranh loi Access is denied khi IIS dang giu handle tren thu muc application.
  Step "Grant IIS folder permissions"
  icacls $Path /grant "IIS APPPOOL\${Pool}:(OI)(CI)(RX)" /T | Out-Host
  icacls $BackendPath /grant "IIS APPPOOL\${BackendPool}:(OI)(CI)(RX)" /T | Out-Host
  icacls $Path /grant "IIS_IUSRS:(OI)(CI)(RX)" /T | Out-Host

  if($ListenPort -eq 80){
    Write-Host "Site URL    : http://localhost/frontend/index.html" -ForegroundColor Green
    Write-Host "Backend API : http://localhost/backend/api/me.ashx" -ForegroundColor Green
  } else {
    Write-Host "Site URL    : http://localhost:${ListenPort}/frontend/index.html" -ForegroundColor Green
    Write-Host "Backend API : http://localhost:${ListenPort}/backend/api/me.ashx" -ForegroundColor Green
  }
  Write-Host "Site AppPool    : IIS APPPOOL\$Pool" -ForegroundColor Green
  Write-Host "Backend AppPool : IIS APPPOOL\$BackendPool" -ForegroundColor Green
}

function Convert-BackendToApplication {
  param(
    [string]$Name,
    [string]$BackendPool,
    [string]$Path
  )

  Step "Convert backend folder to IIS Application"
  Import-Module WebAdministration -ErrorAction Stop

  $BackendPath = Join-Path $Path "backend"
  $BackendIisPath = "IIS:\Sites\$Name\backend"

  if(-not (Test-Path "IIS:\Sites\$Name")){
    throw "Khong tim thay site IIS: $Name"
  }

  if(-not (Test-Path $BackendPath)){
    throw "Khong tim thay thu muc backend vat ly: $BackendPath"
  }

  if(-not (Test-Path "IIS:\AppPools\$BackendPool")){
    New-WebAppPool -Name $BackendPool | Out-Null
  }
  Set-ItemProperty "IIS:\AppPools\$BackendPool" -Name managedRuntimeVersion -Value "v4.0"
  Set-ItemProperty "IIS:\AppPools\$BackendPool" -Name managedPipelineMode -Value "Integrated"
  Set-ItemProperty "IIS:\AppPools\$BackendPool" -Name processModel.identityType -Value "ApplicationPoolIdentity"

  $ExistingBackendApp = Get-WebApplication -Site $Name | Where-Object { $_.path -ieq "/backend" }

  if($ExistingBackendApp){
    Write-Host "Backend trong site '$Name' da la Application. Cap nhat lai AppPool..." -ForegroundColor Yellow
    Set-ItemProperty $BackendIisPath -Name applicationPool -Value $BackendPool
  }
  else {
    Write-Host "Backend trong site '$Name' chua la Application. Dang convert..." -ForegroundColor Yellow

    if(Test-Path $BackendIisPath){
      ConvertTo-WebApplication -PSPath $BackendIisPath -ApplicationPool $BackendPool -Force | Out-Null
    }
    else {
      New-WebApplication -Site $Name -Name "backend" -PhysicalPath $BackendPath -ApplicationPool $BackendPool | Out-Null
    }
  }

  Set-ItemProperty $BackendIisPath -Name applicationPool -Value $BackendPool

  $CheckBackendApp = Get-WebApplication -Site $Name | Where-Object { $_.path -ieq "/backend" }
  if(-not $CheckBackendApp){
    throw "Convert backend thanh Application that bai trong site '$Name'."
  }

  Write-Host "Da convert thanh cong: $Name/backend" -ForegroundColor Green
  Write-Host "Backend IIS Path : $BackendIisPath" -ForegroundColor Green
  Write-Host "Backend AppPool  : $BackendPool" -ForegroundColor Green
}


function Normalize-PhysicalPath {
  param([string]$PhysicalPath)
  if([string]::IsNullOrWhiteSpace($PhysicalPath)){ return $PhysicalPath }

  $expanded = [Environment]::ExpandEnvironmentVariables($PhysicalPath)
  try {
    if(Test-Path $expanded){
      return (Resolve-Path $expanded).Path.TrimEnd('\')
    }
  } catch {}

  return $expanded.TrimEnd('\')
}

function Get-IisVirtualPathFromPhysicalPath {
  param(
    [string]$SitePhysicalPath,
    [string]$TargetPhysicalPath
  )

  $sitePath = Normalize-PhysicalPath -PhysicalPath $SitePhysicalPath
  $targetPath = Normalize-PhysicalPath -PhysicalPath $TargetPhysicalPath

  if([string]::IsNullOrWhiteSpace($sitePath) -or [string]::IsNullOrWhiteSpace($targetPath)){
    return $null
  }

  if(-not $targetPath.StartsWith($sitePath, [StringComparison]::OrdinalIgnoreCase)){
    return $null
  }

  $relative = $targetPath.Substring($sitePath.Length) -replace '^[\\\/]+',''
  if([string]::IsNullOrWhiteSpace($relative)){
    return "/"
  }

  return "/" + ($relative -replace '\\','/')
}

function Ensure-DefaultWebSiteBackendApplication {
  param(
    [string]$DefaultSite,
    [string]$BackendPool,
    [string]$Path
  )

  Step "Final check backend Application inside Default Web Site"
  Import-Module WebAdministration -ErrorAction Stop

  if(-not (Test-Path "IIS:\Sites\$DefaultSite")){
    Write-Host "Khong tim thay site '$DefaultSite'. Bo qua buoc check Default Web Site." -ForegroundColor Yellow
    return
  }

  $BackendPath = Join-Path $Path "backend"
  if(-not (Test-Path $BackendPath)){
    throw "Khong tim thay thu muc backend vat ly: $BackendPath"
  }

  if(-not (Test-Path "IIS:\AppPools\$BackendPool")){
    New-WebAppPool -Name $BackendPool | Out-Null
  }
  Set-ItemProperty "IIS:\AppPools\$BackendPool" -Name managedRuntimeVersion -Value "v4.0"
  Set-ItemProperty "IIS:\AppPools\$BackendPool" -Name managedPipelineMode -Value "Integrated"
  Set-ItemProperty "IIS:\AppPools\$BackendPool" -Name processModel.identityType -Value "ApplicationPoolIdentity"

  $DefaultSiteItem = Get-Item "IIS:\Sites\$DefaultSite"
  $DefaultSitePhysicalPath = $DefaultSiteItem.physicalPath
  $DeployVirtualPath = Get-IisVirtualPathFromPhysicalPath -SitePhysicalPath $DefaultSitePhysicalPath -TargetPhysicalPath $Path

  if([string]::IsNullOrWhiteSpace($DeployVirtualPath)){
    Write-Host "DeployPath khong nam trong physical path cua '$DefaultSite'." -ForegroundColor Yellow
    Write-Host "Default Site Path: $DefaultSitePhysicalPath" -ForegroundColor Yellow
    Write-Host "Deploy Path      : $Path" -ForegroundColor Yellow
    Write-Host "Bo qua convert backend trong '$DefaultSite'." -ForegroundColor Yellow
    return
  }

  if($DeployVirtualPath -eq "/"){
    $BackendVirtualPath = "/backend"
  } else {
    $BackendVirtualPath = "$DeployVirtualPath/backend"
  }

  $BackendIisPath = "IIS:\Sites\$DefaultSite" + ($BackendVirtualPath -replace '/', '\')
  $ExistingBackendApp = Get-WebApplication -Site $DefaultSite | Where-Object { $_.path -ieq $BackendVirtualPath }

  if($ExistingBackendApp){
    Write-Host "Backend '$DefaultSite$BackendVirtualPath' da la Application. Cap nhat lai AppPool..." -ForegroundColor Yellow
    Set-ItemProperty $BackendIisPath -Name applicationPool -Value $BackendPool
  }
  else {
    Write-Host "Backend '$DefaultSite$BackendVirtualPath' chua la Application. Dang convert sau khi IIS da start..." -ForegroundColor Yellow

    if(Test-Path $BackendIisPath){
      ConvertTo-WebApplication -PSPath $BackendIisPath -ApplicationPool $BackendPool -Force | Out-Null
    }
    else {
      $AppCmd = "$env:windir\System32\inetsrv\appcmd.exe"
      if(-not (Test-Path $AppCmd)){
        throw "Khong tim thay appcmd.exe de convert $DefaultSite$BackendVirtualPath"
      }
      & $AppCmd add app "/site.name:$DefaultSite" "/path:$BackendVirtualPath" "/physicalPath:$BackendPath" "/applicationPool:$BackendPool" | Out-Host
      if($LASTEXITCODE -ne 0){
        throw "appcmd add app that bai cho $DefaultSite$BackendVirtualPath. ExitCode=$LASTEXITCODE"
      }
    }
  }

  Set-ItemProperty $BackendIisPath -Name applicationPool -Value $BackendPool

  $CheckBackendApp = Get-WebApplication -Site $DefaultSite | Where-Object { $_.path -ieq $BackendVirtualPath }
  if(-not $CheckBackendApp){
    throw "Final check that bai: backend trong '$DefaultSite$BackendVirtualPath' van chua la Application."
  }

  Write-Host "Default Web Site backend da la Application." -ForegroundColor Green
  Write-Host "Default Site App : $DefaultSite$BackendVirtualPath" -ForegroundColor Green
  Write-Host "Physical Path    : $BackendPath" -ForegroundColor Green
  Write-Host "Backend AppPool  : IIS APPPOOL\$BackendPool" -ForegroundColor Green
}

function Grant-AppPoolDb {
  param([string]$Pool,[string]$Server,[string]$Db,[bool]$UseLogin,[string]$User,[string]$Password)
  if($UseLogin){ Write-Host "Dung SQL Login nen bo qua grant IIS AppPool."; return }
  Step "Grant database permission to IIS AppPool"
  $login="IIS APPPOOL\$Pool"
  $sql=@"
USE master;
GO
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'$login')
BEGIN
    CREATE LOGIN [$login] FROM WINDOWS;
END
GO
USE [$Db];
GO
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'$login')
BEGIN
    CREATE USER [$login] FOR LOGIN [$login];
END
GO
IF IS_ROLEMEMBER(N'db_datareader', N'$login') <> 1
BEGIN
    ALTER ROLE db_datareader ADD MEMBER [$login];
END
IF IS_ROLEMEMBER(N'db_datawriter', N'$login') <> 1
BEGIN
    ALTER ROLE db_datawriter ADD MEMBER [$login];
END
GO
"@
  Invoke-SqlText -Text $sql -Server $Server -UseLogin:$UseLogin -User $User -Password $Password
}

try {
  Assert-Admin
  $ScriptDir = if($PSScriptRoot){$PSScriptRoot}else{Split-Path -Parent $MyInvocation.MyCommand.Path}
  if(-not [IO.Path]::IsPathRooted($SourceZip)){ $SourceZip=Join-Path $ScriptDir $SourceZip }
  if(-not [IO.Path]::IsPathRooted($SampleSql)){ $SampleSql=Join-Path $ScriptDir $SampleSql }

  $SqlServer = Prompt-SqlServerInput -CurrentSqlServer $SqlServer -SkipPrompt:$SkipSqlInstancePrompt
  $SqlServer = Normalize-SqlServerName -Server $SqlServer

  Step "Deploy info"
  Write-Host "SourceZip    : $SourceZip"
  Write-Host "DeployPath   : $DeployPath"
  Write-Host "SiteName     : $SiteName"
  Write-Host "AppPoolName  : $AppPoolName"
  Write-Host "BackendPool  : $BackendAppPoolName"
  Write-Host "Default Site : $DefaultWebSiteName"
  Write-Host "Final Check  : $(-not $SkipDefaultWebSiteBackendFinalCheck)"
  Write-Host "Port         : $Port"
  Write-Host "SqlServer    : $SqlServer"
  Write-Host "Prompt SQL   : $(-not $SkipSqlInstancePrompt)"
  Write-Host "Auto SQL     : $(-not $DisableSqlAutoDetect)"
  Write-Host "DatabaseName : $DatabaseName"
  Write-Host "Recreate DB  : $RecreateDatabase"
  Write-Host "ImportSample : $ImportSampleData"

  $ResolvedSql = Resolve-SqlServerInstance -RequestedServer $SqlServer -UseLogin:$UseSqlLogin -User $SqlUser -Password $SqlPassword -DisableAutoDetect:$DisableSqlAutoDetect
  $SqlServer = $ResolvedSql.Server
  Set-DeployCheck -Name "SQL Instance" -Status "OK" -Message "selected $SqlServer | instance=$($ResolvedSql.InstanceName) | version=$($ResolvedSql.ProductVersion) $($ResolvedSql.ProductLevel) | edition=$($ResolvedSql.Edition)"

  Enable-IISFeatures
  Set-DeployCheck -Name "IIS" -Status "OK" -Message "enabled / ASP.NET 4.x features checked"

  Step "Stop IIS"
  iisreset /stop | Out-Host
  Set-DeployCheck -Name "IIS Stop" -Status "OK" -Message "IIS stopped before deployment"

  Deploy-Files -Zip $SourceZip -Target $DeployPath
  Set-DeployCheck -Name "File" -Status "OK" -Message "copied to directory $DeployPath"
  Update-WebConfig -Config (Join-Path $DeployPath "backend\Web.config") -Server $SqlServer -Db $DatabaseName -UseLogin:$UseSqlLogin -User $SqlUser -Password $SqlPassword
  Set-DeployCheck -Name "Web.config" -Status "OK" -Message "connection string updated for $SqlServer / $DatabaseName"
  Configure-IIS -Name $SiteName -Pool $AppPoolName -BackendPool $BackendAppPoolName -Path $DeployPath -ListenPort $Port
  Set-DeployCheck -Name "IIS Site" -Status "OK" -Message "site/app pools configured: $SiteName, $AppPoolName, $BackendAppPoolName"

  Step "Run create database SQL"
  $create=Join-Path $DeployPath "backend\sql\01_create_database.sql"
  $patched=Join-Path $env:TEMP ("create_db_"+[Guid]::NewGuid().ToString("N")+".sql")
  Patch-CreateDb -InFile $create -OutFile $patched -Db $DatabaseName -DropFirst:$RecreateDatabase
  Invoke-SqlFile -File $patched -Server $SqlServer -UseLogin:$UseSqlLogin -User $SqlUser -Password $SqlPassword
  Set-DeployCheck -Name "SQL Database" -Status "OK" -Message "create/check database executed successfully: $DatabaseName"
  Remove-Item $patched -Force -ErrorAction SilentlyContinue

  Grant-AppPoolDb -Pool $AppPoolName -Server $SqlServer -Db $DatabaseName -UseLogin:$UseSqlLogin -User $SqlUser -Password $SqlPassword
  Grant-AppPoolDb -Pool $BackendAppPoolName -Server $SqlServer -Db $DatabaseName -UseLogin:$UseSqlLogin -User $SqlUser -Password $SqlPassword
  if($UseSqlLogin){
    Set-DeployCheck -Name "SQL Permission" -Status "SKIP" -Message "using SQL Login, skipped IIS AppPool grant"
  } else {
    Set-DeployCheck -Name "SQL Permission" -Status "OK" -Message "granted database permission to IIS APPPOOL\$AppPoolName and IIS APPPOOL\$BackendAppPoolName"
  }

  $migration=Join-Path $DeployPath "backend\sql\04_add_saving_type.sql"
  if(Test-Path $migration){
    Step "Run migration SQL"
    $patchedMig=Join-Path $env:TEMP ("migration_"+[Guid]::NewGuid().ToString("N")+".sql")
    Patch-UseDb -InFile $migration -OutFile $patchedMig -Db $DatabaseName
    Invoke-SqlFile -File $patchedMig -Server $SqlServer -UseLogin:$UseSqlLogin -User $SqlUser -Password $SqlPassword
    Set-DeployCheck -Name "SQL Migration" -Status "OK" -Message "migration executed successfully"
    Remove-Item $patchedMig -Force -ErrorAction SilentlyContinue
  }

  if(-not (Test-Path $migration)){
    Set-DeployCheck -Name "SQL Migration" -Status "SKIP" -Message "migration file not found"
  }

  if($ImportSampleData){
    Step "Import sample data"
    if(-not (Test-Path $SampleSql)){
      $inside=Join-Path $DeployPath "backend\sql\06_sample_data_2025_01_to_2026_06.sql"
      if(Test-Path $inside){ $SampleSql=$inside } else { throw "Khong tim thay SampleSql: $SampleSql" }
    }
    $patchedSample=Join-Path $env:TEMP ("sample_"+[Guid]::NewGuid().ToString("N")+".sql")
    Patch-UseDb -InFile $SampleSql -OutFile $patchedSample -Db $DatabaseName
    Invoke-SqlFile -File $patchedSample -Server $SqlServer -UseLogin:$UseSqlLogin -User $SqlUser -Password $SqlPassword
    Set-DeployCheck -Name "Sample Data" -Status "OK" -Message "sample data imported successfully"
    Remove-Item $patchedSample -Force -ErrorAction SilentlyContinue
  } else {
    Set-DeployCheck -Name "Sample Data" -Status "SKIP" -Message "ImportSampleData not selected"
  }

  # Dat buoc Convert backend thanh Application o CUOI cung, ngay truoc khi Start IIS.
  # Cach nay tranh loi Access is denied sau khi folder backend da bi IIS convert va khoa quyen/handle.
  Convert-BackendToApplication -Name $SiteName -BackendPool $BackendAppPoolName -Path $DeployPath
  Set-DeployCheck -Name "IIS Backend" -Status "OK" -Message "backend converted to Application successfully in site $SiteName"

  Step "Start IIS"
  iisreset /start | Out-Host
  Set-DeployCheck -Name "IIS Start" -Status "OK" -Message "IIS started"
  Start-Sleep -Seconds 2

  # Sau khi IIS vua duoc enable/start lai, module IIS co the moi nap day du.
  # Check lai lan cuoi va convert backend nam trong Default Web Site
  # vi backend duoi Default Web Site co the bi giu dang folder thuong sau khi cai lai IIS/.NET.
  if(-not $SkipDefaultWebSiteBackendFinalCheck){
    Ensure-DefaultWebSiteBackendApplication -DefaultSite $DefaultWebSiteName -BackendPool $BackendAppPoolName -Path $DeployPath
    Set-DeployCheck -Name "Default Web Site Backend" -Status "OK" -Message "backend final check/convert completed"
  } else {
    Set-DeployCheck -Name "Default Web Site Backend" -Status "SKIP" -Message "SkipDefaultWebSiteBackendFinalCheck selected"
  }

  Step "DONE"
  if($Port -eq 80){
    Write-Host "URL: http://localhost/frontend/index.html" -ForegroundColor Green
  } else {
    Write-Host "URL: http://localhost:${Port}/frontend/index.html" -ForegroundColor Green
  }
  Write-Host "Backend API: http://localhost:${Port}/backend/api/me.ashx" -ForegroundColor Green
  Write-Host "Login: admin / admin123" -ForegroundColor Green
  Print-DeployChecklist
}
catch {
  Write-Host ""
  Write-Host "DEPLOY FAILED" -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Set-DeployCheck -Name "Deploy Result" -Status "FAIL" -Message $_.Exception.Message
  Print-DeployChecklist -Title "DEPLOY CHECKLIST - PARTIAL"
  try { iisreset /start | Out-Host } catch {}
  exit 1
}
