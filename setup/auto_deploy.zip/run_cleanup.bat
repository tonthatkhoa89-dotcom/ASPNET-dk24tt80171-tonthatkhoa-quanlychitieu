@echo off
setlocal

REM Chay file nay bang Run as Administrator.
REM Script se xoa IIS site/app pool, drop database va xoa source trong wwwroot.
REM Sua SqlServer neu may ban khong dung .\SQLEXPRESS01.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0cleanup_personal_finance_iis.ps1" ^
  -SiteName "PersonalFinanceOffline" ^
  -AppPoolName "PersonalFinanceOffline" ^
  -DeployPath "C:\inetpub\wwwroot\PersonalFinanceOffline" ^
  -SqlServer ".\SQLEXPRESS" ^
  -DatabaseName "PersonalFinanceDb" ^
  -DeleteBackups

pause
