@echo off
setlocal

REM Chay file nay bang Run as Administrator.
REM Sua SqlServer neu may ban khong dung .\SQLEXPRESS.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy_personal_finance_iis.ps1" ^
  -SourceZip "%~dp0PersonalFinanceOffline_FINAL.zip" ^
  -SampleSql "%~dp006_sample_data_2025_01_to_2026_06.sql" ^
  -SiteName "PersonalFinanceOffline" ^
  -AppPoolName "PersonalFinanceOffline" ^
  -DeployPath "C:\inetpub\wwwroot\PersonalFinanceOffline" ^
  -Port 80 ^
  -SqlServer ".\SQLEXPRESS" ^
  -DatabaseName "PersonalFinanceDb" ^
  -RecreateDatabase ^
  -ImportSampleData

pause
